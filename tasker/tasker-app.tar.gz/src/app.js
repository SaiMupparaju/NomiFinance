// src/app.js
const dotenv = require('dotenv');
dotenv.config({path : '../.env'});


const express = require('express');
const bodyParser = require('body-parser');
const scheduleRoutes = require('./routes/scheduleRoutes');
const agenda = require('./agenda');
const cors = require('cors');

const app = express();

// Middleware to authenticate requests
const authenticateRequest = (req, res, next) => {
  const token = req.headers['authorization']; // Get the token from the header
  const expectedToken = process.env.TASKER_API_KEY; // Get the expected token from the environment variable

  if (token && token === `Bearer ${expectedToken}`) {
    return next(); // Token matches, proceed to the next middleware or route handler
  }
  return res.status(401).json({ message: 'Unauthorized' });
};

// Apply the authentication middleware to all routes
app.use(authenticateRequest);
  
app.use(cors());

app.use(bodyParser.json());



// Use the scheduling routes
app.use('/', scheduleRoutes);

agenda.start().then(() => {
  console.log('Agenda started!');
});


module.exports = app;